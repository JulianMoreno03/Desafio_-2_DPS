import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ListaPlato from './ListaPlato';
import DetallePlato from './DetallePlato';

const Stack = createStackNavigator();
const Plato = () => {
  return (
    <Stack.Navigator initialRouteName="Paises">
      <Stack.Screen
        name="Plato"
        component={ListaPlato}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="DetallePlato"
        component={DetallePlato}
        options={{
          headerShown: false,
        }}
      />
    </Stack.Navigator>
  );
};
export default Plato;
