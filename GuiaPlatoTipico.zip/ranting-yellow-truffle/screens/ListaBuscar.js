import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, Image, TouchableOpacity, TextInput } from 'react-native';

const ListaBuscar= ({ navigation }) => {
  const [platos, setPlatos] = useState([]);
  const [busqueda, setBusqueda] = useState('');

  useEffect(() => {
    fetch('https://661454bf2fc47b4cf27c246c.mockapi.io')
      .then(response => response.json())
      .then(data => setPlatos(data))
      .catch(error => console.error(error));
  }, []);

  const handleBusqueda = (text) => {
    setBusqueda(text);
  }

  const filtrarPlatos = (plato) => {
    return plato.nombre.toLowerCase().includes(busqueda.toLowerCase()) || plato.categoria.toLowerCase().includes(busqueda.toLowerCase());
  }

  const renderItem = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('DetallePlato', { plato: item })}>
      <View>
        <Image source={{ uri: item.imagen }} style={{ width: 50, height: 50 }} />
        <Text>{item.nombre}</Text>
        <Text>{item.categoria}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View>
      <TextInput
        style={{ height: 40, borderColor: 'gray', borderWidth: 1, marginBottom: 10, paddingHorizontal: 10 }}
        placeholder="Buscar plato..."
        onChangeText={handleBusqueda}
        value={busqueda}
      />
      <FlatList
        data={platos.filter(filtrarPlatos)}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </View>
  );
};

export default ListaBuscar;