import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import ListaCategoriaLiz from './ListaCategoria';
import DetalleCategoria from './ListaCategoria';

const Stack = createStackNavigator();

const Categoria = () => {
  return (
    <Stack.Navigator initialRouteName="Categoria">
      <Stack.Screen
        name="Categoria"
        component={Categoria}
        options={{
          headerShown: false,
         }} />
      </Stack.Navigator>
  );
};

export default Categoria;
