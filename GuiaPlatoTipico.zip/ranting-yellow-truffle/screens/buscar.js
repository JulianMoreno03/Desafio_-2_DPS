import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import ListaBuscar from './ListaBuscar'; 

const Tab = createBottomTabNavigator();

const Buscar = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Busqueda" component={Busqueda} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default Buscar;